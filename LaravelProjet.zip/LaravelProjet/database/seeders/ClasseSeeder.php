<?php

namespace Database\Seeders;

use App\Models\Niveau;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class ClasseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $classes=['2nd','1ere'];
        $elementaire=Niveau::where('id',3)->first();
        foreach ($classes as $classe ) {

           DB::table('classes')->insert([
            "nom" =>$classe,
            "niveau_id" =>$elementaire->id
           ]);
          
        }

    }
}
