<?php

namespace App\Traits;

trait JoinQueryParams{
    public function test()  {
        dd('Hadeejah');
    }
}
