<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Eleve extends Model
{
    use HasFactory;
    protected $guarded=['id'];
    public function __construct() {
        // $this->var = $var;
        $this->numero=1234;
        // $this->genereNumber();
    }

   public static function genereNumber() {
        
    return $num=Eleve::WhereNotNull('numero')->max('numero')+1;


    }

    protected $fillable = [
        'nom',
        'prenom',
        'dateNaissance',
        'lieuNaissance',
        'sexe',
        'profile',
        'etat',
        'numero'
    ];

    
}

