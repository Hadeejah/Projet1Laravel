<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Carbon\Carbon;

class EleveRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array|string>
     */
    public function rules(): array
    {
        
        return [
            'nom' => 'bail|required|between:2,250|alpha',
            'prenom' => 'bail|required|',
            'dateNaissance' => 'bail|required|date|before:today -5years',
            'lieuNaissance' => 'bail|required|max:250|alpha',
            'sexe' => 'bail|required|in:M,F',
            'profile' => 'bail|required|in:0,1'

        ];
    }
}