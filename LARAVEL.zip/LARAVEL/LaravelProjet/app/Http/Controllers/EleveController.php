<?php

namespace App\Http\Controllers;

use App\Http\Requests\EleveRequest;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\Eleve;
use App\Models\Inscription;
use App\Models\Classe;
use Illuminate\Support\Facades\DB;


class EleveController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(EleveRequest $request)
    {
        $validation = Validator::make($request->all(), [
            "nom" => "required",
            "prenom" => "required",
            "profile" => "required",
            "dateNaissance" => "sometimes:required|",
            "lieuNaissance" => "sometimes:required",
            "sexe" => "required",

        ]);
        $profile = $request->input("profile");

        $num = null;
        if ($profile == 0) {
            $num = Eleve::genereNumber();

        }

        $eleve = Eleve::create(array_merge($validation->validated(), ['numero' => $num]));

        $ideleve = $eleve->id;
        $inscrip = Inscription::create([
            "niveau_id" => $request->input("niveau"),
            "classe_id" => $request->input("classe"),
            "eleve_id" => $ideleve
        ]);
        return $eleve;

    }

    public function listEleve($classeId)
    {

        $eleves = DB::table('classes')
            ->join('inscriptions', 'classes.id', '=', 'inscriptions.classe_id')
            ->join('eleves', 'inscriptions.eleve_id', '=', 'eleves.id')
            ->select('eleves.id', 'eleves.nom', 'eleves.prenom')
            ->where('classes.id', $classeId)
            ->get();

        return $eleves;
    }

 

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {

    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}