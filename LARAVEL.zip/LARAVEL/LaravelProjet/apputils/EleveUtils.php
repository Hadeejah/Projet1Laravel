<?php

namespace App\Utils;

class EleveUtils {
    public static function genererNumeroEleve() {
        $prefixe = "ELEVE";
        $numero = uniqid(); // Génère un identifiant unique basé sur le timestamp actuel
        
        return $prefixe . '-' . $numero;
    }
}
